setwd("C:\\Users\\it24102172\\Desktop\\IT24102172")

branch_data <- read.table("Exercise.txt", header = TRUE, sep = ",")
str(branch_data)
boxplot(branch_data$Sales_X1, main = "Boxplot for sales", ylab = "Sales")
summary(branch_data$Advertising_X2)
IQR(branch_data$Advertising_X2)

find_outliners <- function(x) {
  Q1 <- quantile(x, 0.25)
  Q3 <- quantile(x, 0.75)
  IQR_value <- IQR(x)
  lower_bound <- Q1 - 1.5 * IQR_value
  upper_bound <- Q3 + 1.5 * IQR_value
  outliners <- x[x< lower_bound | x > upper_bound]
  return(outliners)
}

outliners_advertising <- find_outliners(branch_data$Advertising_X2)
outliners_advertising
